export class Skill{
    constructor(public skillId:number,public skillName:string){
        
    }
}