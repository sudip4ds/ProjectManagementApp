import { Employee } from "./Employee";

export class Status{
    constructor(public emp:Employee,public flag:boolean){
        
    }
}