import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Employee } from '../Employee';
import { Project } from '../Project';
import { Skill } from '../Skill';

@Component({
  selector: 'app-manager',
  templateUrl: './manager.component.html',
  styleUrls: ['./manager.component.css']
})
export class ManagerComponent implements OnInit {

  constructor(public router:Router,public route: ActivatedRoute,private httpclient:HttpClient) { }

  ngOnInit(): void {
  }

  @Input()
  employee=null;




}
